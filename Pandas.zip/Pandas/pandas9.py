# -*- coding: utf-8 -*-
"""
Created on Fri Jul 21 12:26:36 2023

@author: u398142
"""

import pandas as pd


fruits = ['apples', 'oranges', 'cherries', 'pears']


S = pd.Series([20, 33, 52, 10], index=fruits)


J=S.apply(lambda x: x if x > 50 else x+10 )
print(J)
