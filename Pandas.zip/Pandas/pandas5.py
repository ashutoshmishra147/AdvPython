# -*- coding: utf-8 -*-
"""
Created on Fri Jul 21 12:10:38 2023

@author: u398142
"""

import pandas as pd

fruits = ['peaches', 'oranges', 'cherries', 'pears']
fruits2 = ['raspberries', 'oranges', 'cherries', 'pears']

S = pd.Series([20, 33, 52, 10], index=fruits)
S2 = pd.Series([17, 13, 31, 32], index=fruits2)
print(S + S2)