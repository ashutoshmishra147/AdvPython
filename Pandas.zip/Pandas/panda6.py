# -*- coding: utf-8 -*-
"""
Created on Fri Jul 21 12:15:04 2023

@author: u398142
"""

import pandas as pd

fruits = ['apples', 'oranges', 'cherries', 'pears']

S = pd.Series([20, 33, 52,23], index=fruits)

#S = pd.Series([11, 28, 72, 3, 5, 8])
#print(S)

print(S[['apples', 'oranges', 'cherries']])
