# -*- coding: utf-8 -*-
"""
Created on Fri Jul 21 12:22:08 2023

@author: u398142
"""

import numpy as np
S = np.array([11, 28, 72, 3, 5, 8])


print((S + 3) * 4)
print("======================")
print(np.sin(S))