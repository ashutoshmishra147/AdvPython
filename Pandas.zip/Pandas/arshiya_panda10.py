# -*- coding: utf-8 -*-
"""
Created on Fri Jul 21 12:42:09 2023

@author: u398142
"""

import pandas as pd

#import numpy as np

fruits = ['apples', 'oranges', 'cherries', 'pears']

S = pd.Series([20, 33, 52, 10], index=fruits)

#S2 = pd.Series([17, 13, 31, 32], index=fruits)
 

f= list(map(lambda x: x if x > 50 else x+10, S))

print(f)