# -*- coding: utf-8 -*-
"""
Created on Fri Jul 21 11:56:58 2023

@author: u398142
"""

import numpy as np
import pandas as pd
X = np.array([11, 28, 72, 3, 5, 8])
print(X)

S = pd.Series([11, 28, 72, 3, 5, 8])
print(S);


#print(S.values)
# both are the same type:
print(type(S.values), type(X));