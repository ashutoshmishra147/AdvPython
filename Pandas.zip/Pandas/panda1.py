# -*- coding: utf-8 -*-
"""
Created on Fri Jul 21 11:54:54 2023

@author: u398142
"""

import pandas as pd
S = pd.Series([11, 28, 72, 3, 5, 8])
print(S);
print(S.index)
print(S.values)