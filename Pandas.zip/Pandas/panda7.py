# -*- coding: utf-8 -*-
"""
Created on Fri Jul 21 12:14:30 2023

@author: u398142
"""

import pandas as pd

fruits = ['apples', 'oranges', 'cherries', 'pears']

fruits_tr = ['elma', 'portakal', 'kiraz', 'armut']

S = pd.Series([20, 33, 52, 10], index=fruits)
S2 = pd.Series([17, 13, 31, 32], index=fruits_tr)
print(S + S2)