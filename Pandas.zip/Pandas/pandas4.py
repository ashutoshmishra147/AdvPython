# -*- coding: utf-8 -*-
"""
Created on Fri Jul 21 12:06:04 2023

@author: u398142
"""

import pandas as pd

fruits = ['apples', 'oranges', 'cherries', 'pears']

S = pd.Series([20, 33, 52, 10], index=fruits)
S2 = pd.Series([17, 13, 31, 32], index=fruits)
print("the values of S is ",S)
print("the values of S2 is ",S2)

print("total values: ",S+S2)

#print("sum of S: ", sum(S))