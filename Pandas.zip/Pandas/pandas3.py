# -*- coding: utf-8 -*-
"""
Created on Fri Jul 21 12:04:04 2023

@author: u398142
"""

import pandas as pd

fruits = ['apples', 'oranges', 'pears']
quantities = [20, 33, 52, 10 ]
S = pd.Series(quantities, index=fruits)
print(S)