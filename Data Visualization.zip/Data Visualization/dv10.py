# -*- coding: utf-8 -*-
"""
Created on Mon Jul 24 11:38:20 2023

@author: u398142
"""

import matplotlib.pyplot as plt
import seaborn as sns

#Creating the dataset
df = sns.load_dataset("iris") 
df=df.groupby('sepal_length')['sepal_width'].sum().to_frame().reset_index()
#Creating the line chart
plt.plot(df['sepal_length'], df['sepal_width']) 
#Adding the aesthetics
plt.title('Chart title')
plt.xlabel('X axis title')
plt.ylabel('Y axis title') 
#Show the plot
plt.show()