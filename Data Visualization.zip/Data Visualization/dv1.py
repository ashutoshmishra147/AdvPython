# -*- coding: utf-8 -*-
"""
Created on Mon Jul 24 11:08:29 2023

@author: u398142
"""

import pandas as pd
 
 
# reading the database
#data = pd.read_csv("tips.csv")
 
data = pd.read_csv("titanic.csv")

# printing the top 10 rows
print(data.head(10))
