# -*- coding: utf-8 -*-
"""
Created on Mon Jul 24 11:30:19 2023

@author: u398142
"""

import seaborn as sns
import matplotlib.pyplot as plt
import pandas as pd
import numpy as np

#Creating the dataset
df = sns.load_dataset('titanic')
df_pivot = pd.pivot_table(df, values="fare",index="who",columns="class", aggfunc=np.mean)
#Creating a grouped bar chart
ax = df_pivot.plot(kind="bar",alpha=1.0)
#Adding the aesthetics
plt.title('Chart title')
plt.xlabel('X axis title')
plt.ylabel('Y axis title') 
# Show the plot
plt.show()