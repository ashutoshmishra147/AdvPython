# -*- coding: utf-8 -*-
"""
Created on Mon Jul 24 11:37:40 2023

@author: u398142
"""
import matplotlib.pyplot as plt
import pandas as pd

dataframe = pd.DataFrame(columns=["A","B", "C","D"], 
                  data=[["E",0,1,1],
                        ["F",1,1,0],
                        ["G",0,1,0]])
dataframe.set_index('A').T.plot(kind='bar', stacked=True)
#Adding the aesthetics
plt.title('Chart title')
plt.xlabel('X axis title')
plt.ylabel('Y axis title') 
# Show the plot
plt.show()