# -*- coding: utf-8 -*-
"""
Created on Mon Jul 24 11:29:32 2023

@author: u398142
"""
import seaborn as sns
import matplotlib.pyplot as plt

#Reading the dataset
titanic_dataset = sns.load_dataset('titanic')
#Creating column chart
sns.barplot(x = 'who',y = 'fare',data = titanic_dataset,palette = "Blues")
#Adding the aesthetics
plt.title('Chart title')
plt.xlabel('X axis title')
plt.ylabel('Y axis title') 
# Show the plot
plt.show()