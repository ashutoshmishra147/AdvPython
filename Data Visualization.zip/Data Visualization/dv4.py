# -*- coding: utf-8 -*-
"""
Created on Mon Jul 24 11:28:05 2023

@author: u398142
"""

import seaborn as sns
import matplotlib.pyplot as plt

df = sns.load_dataset('titanic') 
df=df.groupby('who')['fare'].sum().to_frame().reset_index()
#Creating the column plot 
plt.bar(df['who'],df['fare'],color = ['#F0F8FF','#E6E6FA','#B0E0E6']) 
#Adding the aesthetics
plt.title('Chart title')
plt.xlabel('X axis title')
plt.ylabel('Y axis title') 
#Show the plot
plt.show()