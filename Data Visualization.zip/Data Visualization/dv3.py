# -*- coding: utf-8 -*-
"""
Created on Mon Jul 24 11:22:17 2023

@author: u398142
"""

import seaborn as sns
import matplotlib.pyplot as plt

#Creating bar plot
sns.barplot(x = 'fare',y = 'who',data = "titanic.csv", palette = "Blues")

#Adding the aesthetics
plt.title('Chart title')
plt.xlabel('X axis title')
plt.ylabel('Y axis title') 
# Show the plot
plt.show()
